// Modules to control application life and create native browser window
const {app, BrowserWindow, ipcMain} = require('electron')
const {dialog} = require('electron')
const extract = require('extract-zip')
const fs = require("fs")
const path = require('path')

function createWindow() {
    // Create the browser window.
    const mainWindow = new BrowserWindow({
        width: 800,
        height: 400,
        autoHideMenuBar: true,

        webPreferences: {
            preload: path.join(__dirname, 'preload.js')
        }
    })

    // and load the index.html of the app.
    mainWindow.loadFile('index.html')

    // Open the DevTools.
    // mainWindow.webContents.openDevTools()

    return mainWindow
}


async function extractAllZipInDir(dirPath, mainWindow) {
    const files = fs.readdirSync(dirPath);

    await Promise.all(
        files.map(async (file) => {
            if (fs.statSync(dirPath + "/" + file).isDirectory()) {
                await extractAllZipInDir(path.join(dirPath, file), mainWindow);
            } else {
                const fullFilePath = path.join(dirPath, file);

                console.log(mainWindow)

                mainWindow.send( 'traverse-log',  fullFilePath  )

                // const folderName = file.replace(".zip", "");
                // if (file.endsWith(".zip")) {
                //   zippedFiles.push(folderName);
                //   await extractZip(fullFilePath, path.join(dirPath, "/", folderName));
                //   await unzipFiles(path.join(dirPath, "/", folderName));
                // }
            }
        })
    );
}


function handleOpenDir(mainWindow, event, title) {

    dialog.showOpenDialog({properties: ['openDirectory']}).then(async (rslt) => {
        // console.log('rslt', rslt)

        if(!rslt.canceled) {
            await extractAllZipInDir(rslt.filePaths[0], mainWindow)

            mainWindow.send( 'traverse-log',  '작업을 모두 완료했습니다.'  )
        }
    })
}


// This method will be called when Electron has finished
// initialization and is ready to create browser windows.
// Some APIs can only be used after this event occurs.
app.whenReady().then(() => {


    let mainWindow = createWindow()

    ipcMain.on('openDirPopup', handleOpenDir.bind(null, mainWindow))

    app.on('activate', function () {
        // On macOS it's common to re-create a window in the app when the
        // dock icon is clicked and there are no other windows open.
        if (BrowserWindow.getAllWindows().length === 0) {
            mainWindow = createWindow()
        }
    })

    // mainWindow.webContents.openDevTools()

    // console.log(dialog.showOpenDialog({ properties: ['openFile', 'multiSelections'] }))
})

// Quit when all windows are closed, except on macOS. There, it's common
// for applications and their menu bar to stay active until the user quits
// explicitly with Cmd + Q.
app.on('window-all-closed', function () {
    if (process.platform !== 'darwin') app.quit()
})

// In this file you can include the rest of your app's specific main process
// code. You can also put them in separate files and require them here.


